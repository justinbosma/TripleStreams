
        # MIDI Collection

        ## Summary
        This collection contains 500 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 500
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 50, ('Pop',): 50, ('Jazz',): 50, ('Blues',): 50, ('Funk',): 50, ('Latin',): 50, ('Disco',): 50, ('Afro',): 50, ('Hip-Hop/R&B/Soul',): 50, ('Rock',): 50}

        ## Meter Distribution
        {'[4_4]': 500}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 114.80408, 'median': 115.0, 'std_dev': 28.780682704786557}

        