
        # MIDI Collection

        ## Summary
        This collection contains 100 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 100
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 10, ('Pop',): 10, ('Jazz',): 10, ('Blues',): 10, ('Funk',): 10, ('Latin',): 10, ('Disco',): 10, ('Afro',): 10, ('Hip-Hop/R&B/Soul',): 10, ('Rock',): 10}

        ## Meter Distribution
        {'[4_4]': 100}

        ## Tempo Distribution
        {'min': 64.0, 'max': 182.0, 'mean': 110.03, 'median': 110.0, 'std_dev': 22.173612696175603}

        