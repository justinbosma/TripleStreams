
        # MIDI Collection

        ## Summary
        This collection contains 800 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 800
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 80, ('Pop',): 80, ('Jazz',): 80, ('Blues',): 80, ('Funk',): 80, ('Latin',): 80, ('Disco',): 80, ('Afro',): 80, ('Hip-Hop/R&B/Soul',): 80, ('Rock',): 80}

        ## Meter Distribution
        {'[4_4]': 800}

        ## Tempo Distribution
        {'min': 64.0, 'max': 290.0, 'mean': 112.77625, 'median': 110.0, 'std_dev': 31.83930253534937}

        