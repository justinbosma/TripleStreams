
        # MIDI Collection

        ## Summary
        This collection contains 24140 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 24140
        Mechanical Files: 0

        ## Genre Distribution
        {('Afro',): 2540, ('Reggae',): 2400, ('Pop',): 2400, ('Jazz',): 2400, ('Blues',): 2400, ('Funk',): 2400, ('Latin',): 2400, ('Disco',): 2400, ('Hip-Hop/R&B/Soul',): 2400, ('Rock',): 2400}

        ## Meter Distribution
        {'[4_4]': 24140}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 115.3848385629832, 'median': 120.0, 'std_dev': 26.87428989715767}

        