
        # MIDI Collection

        ## Summary
        This collection contains 3019 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 3019
        Mechanical Files: 0

        ## Genre Distribution
        {('Afro',): 319, ('Reggae',): 300, ('Pop',): 300, ('Jazz',): 300, ('Blues',): 300, ('Funk',): 300, ('Latin',): 300, ('Disco',): 300, ('Hip-Hop/R&B/Soul',): 300, ('Rock',): 300}

        ## Meter Distribution
        {'[4_4]': 3019}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 114.87682193591017, 'median': 120.0, 'std_dev': 25.39915063928167}

        