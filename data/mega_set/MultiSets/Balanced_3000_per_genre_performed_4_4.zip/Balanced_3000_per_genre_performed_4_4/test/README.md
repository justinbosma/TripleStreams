
        # MIDI Collection

        ## Summary
        This collection contains 3017 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 3017
        Mechanical Files: 0

        ## Genre Distribution
        {('Afro',): 317, ('Reggae',): 300, ('Pop',): 300, ('Jazz',): 300, ('Blues',): 300, ('Funk',): 300, ('Latin',): 300, ('Disco',): 300, ('Hip-Hop/R&B/Soul',): 300, ('Rock',): 300}

        ## Meter Distribution
        {'[4_4]': 3017}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 116.15540495867768, 'median': 120.0, 'std_dev': 28.306500413552232}

        