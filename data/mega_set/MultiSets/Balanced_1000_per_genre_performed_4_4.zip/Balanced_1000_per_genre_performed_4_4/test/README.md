
        # MIDI Collection

        ## Summary
        This collection contains 1048 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 1048
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 148, ('Pop',): 100, ('Jazz',): 100, ('Blues',): 100, ('Funk',): 100, ('Latin',): 100, ('Disco',): 100, ('Afro',): 100, ('Hip-Hop/R&B/Soul',): 100, ('Rock',): 100}

        ## Meter Distribution
        {'[4_4]': 1048}

        ## Tempo Distribution
        {'min': 64.0, 'max': 290.0, 'mean': 115.18893129770993, 'median': 120.0, 'std_dev': 27.219432600104195}

        